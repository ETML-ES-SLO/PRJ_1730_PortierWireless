#include "GestBuzzer.h"
#include "peripheral/ports/plib_ports.h"



void singLa()
{
    //Joue un LA
    //11 * 10 us fait une demi periode de 440Hz (La)
    if(BUZ_TIME < (11))
    {
        PLIB_PORTS_PinWrite(0,0x01,15, 0);
    }
    else
    {
        PLIB_PORTS_PinWrite(0,0x01,15, 1);
        if(BUZ_TIME > (22))
        {
            BUZ_TIME = 0;
        }
    }
}



void songDo()
{
    //Joue un DO
    //19 * 10 us fait une demi periode de 263Hz (Do)
    if(BUZ_TIME < 19)
    {
        PLIB_PORTS_PinWrite(0,0x01,15, 0);
    }
    else
    {
        PLIB_PORTS_PinWrite(0,0x01,15, 1);
        if(BUZ_TIME > 38)
        {
            BUZ_TIME = 0;
        }
    }
}