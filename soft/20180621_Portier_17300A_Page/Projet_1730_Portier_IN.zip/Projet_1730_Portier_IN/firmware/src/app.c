#include "app.h"
#include "GestBuzzer.h"
#include "Mc32gest_RS232.h"


APP_DATA appData;
APP_STEP progress;
APP_ANSWER appAnswer;

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;

}




void APP_Tasks ( void )
{
    static uint8_t tensionPile = 0;
    static bool visiteManque = false;
    
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            //Initialisation des PORTS
            PORTS_INIT();

            //Start les timers
            DRV_TMR0_Start();
            DRV_TMR1_Start();
            
            
            progress = WAIT;
            appData.state = APP_STATE_SERVICE_TASKS;
            break;
        }

        case APP_STATE_SERVICE_TASKS:
        {
            switch(progress)
            {
                //Attend la sonnette
                case WAIT:

                    //Attends de recevoir un message
                    if(GetMessage(&tensionPile))
                    {
                        
                        //Passe � l'�tape suivante
                        progress = ASK;
                        //Reset le temps
                        TEMPS = 0;
                        
                    }
                    
                    //Si on a manque une visite
                    if(visiteManque)
                    {
                        //Toggle la LED request chaque seconde
                        if(TEMPS > 0)
                        {
                            PLIB_PORTS_PinToggle(PORTS_ID_0, 0x01, 6);
                            TEMPS = 0;
                        }
                        
                        //Lecture des poussoirs
                        appAnswer.occupe = PLIB_PORTS_PinGet(0,0x01,9);
                        appAnswer.attendez = PLIB_PORTS_PinGet(0,0x01,8);
                        appAnswer.entrez = PLIB_PORTS_PinGet(0,0x01,7);
                        //Si on a 
                        //Valider le clignotement
                        if(!appAnswer.occupe || !appAnswer.attendez || !appAnswer.entrez)
                        {
                            //Clear l'info de la visite manquee
                            visiteManque = false;
                        }
                    }
                    else
                    {
                        //Eteint la LED request
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, false);
                    }

                    break;
                
                //Demande r�ponse et indique informations
                case ASK:
                    
                    //Allume la LED request
                    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, true);
                    
                    //Si piles doivent �tre changees
                    if(tensionPile == L)
                    {
                        //Allume "LowBat"
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, true);
                        //Eteint "ComError"
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, false);
                    }
                    //Si piles sont OK
                    else if(tensionPile == F)
                    {
                        //Eteint "LowBat" et "ComError"
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, false);
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, false);
                    }
                    //fausse information
                    else
                    {
                        //Allume "ComError"
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, true);
                    }
                    
                    //Sonne pendant une seconde
                    singLa();
                    if(TEMPS > 1)
                    {
                        //Passe � l'�tape suivante
                        progress = WAIT_ANSWER;
                    }
                    
                    break;
                
                //Attends r�ponse du prof
                case WAIT_ANSWER:
                    
                    //Lecture des switchs
                    appAnswer.occupe = PLIB_PORTS_PinGet(0,0x01,9);
                    appAnswer.attendez = PLIB_PORTS_PinGet(0,0x01,8);
                    appAnswer.entrez = PLIB_PORTS_PinGet(0,0x01,7);
                    
                    //Analyse si occupe
                    if(!appAnswer.occupe)
                    {
                        //Envois l'info occupe => O
                        sendMessage(ADRESSE_OUT, O);

                        //Retourne a l'attente du prochain message
                        progress = WAIT;
                    }
                    //Analyse si attendez
                    else if(!appAnswer.attendez)
                    {
                        //Envois l'info attendez A
                        sendMessage(ADRESSE_OUT, A);
                        
                        //Retourne a l'attente du prochain message
                        progress = WAIT;
                    }
                    //Analyse si entrez
                    else if(!appAnswer.entrez)
                    {
                        //Envois l'info entrez => E
                        sendMessage(ADRESSE_OUT, E);
                        
                        //Retourne a l'attente du prochain message
                        progress = WAIT;
                    }
                    //Si on atend trop long
                    else if(TEMPS > 30)
                    {
                        //Retourne � l'attente du prochain message
                        progress = WAIT;
                        //Indique une visite manqu�e
                        visiteManque = true;
                    }
                    break;
               
                    
                default:
                    
                    break;
                
            }
            break;
        }

        /* TODO: implement your application state machine.*/
        

        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}

 

void PORTS_INIT()
{
    //LED eteintes
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, false);
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, false);
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, false);
    
    //SWITCHS
    //PORTB PIN 7 --> SW1
    //PORTB PIN 8 --> SW2
    //PORTB PIN 9 --> SW3
    
    //BUZZER
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 15, false);
    
    //Module RF
    
    //Reset
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 12, false);
    
    // To set reset(M) low :
//    _TRISB12=0;
    
      // To set reset(M) high :
    //_TRISB12=1;
    
    //Connect
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 13, true);
    
    //Attends que LINK passe a 1
    //PORTB --> PIN 14 : LINK
    while(!PLIB_PORTS_PinGet(PORTS_ID_0, 0x01, 14))
    {
        //Allume 3�me LED tant que pas LINK
        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, true);
    }
    //Eteint 3�me LED quand LINK
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, false);

    
}