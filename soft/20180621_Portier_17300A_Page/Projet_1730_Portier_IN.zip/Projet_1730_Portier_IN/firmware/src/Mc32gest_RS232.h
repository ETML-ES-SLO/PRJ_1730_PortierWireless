#ifndef Mc32Gest_RS232_H
#define Mc32Gest_RS232_H

/* 
 * File:   Mc32gest_RS232.h
 * Author: pageis
 *
 * Created on 13. mars 2018, 11:23
 */

#include <stdint.h>




/*--------------------------------------------------------*/
// D�finition des fonctions prototypes
/*--------------------------------------------------------*/

// prototypes des fonctions
bool GetMessage(uint8_t *dataRecieved);
void sendMessage(unsigned int addr, uint8_t data);


#endif
