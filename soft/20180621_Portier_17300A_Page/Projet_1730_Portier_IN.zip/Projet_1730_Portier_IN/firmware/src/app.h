#ifndef _APP_H
#define _APP_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 

#define ADRESSE_OUT 0x0021500A
#define MY_ADDRESS 0x0020B626

// F = bat Full
// L = Low bat
#define F 0x46
#define L 0x4C
    
// O = Occup�
// A = Attendez
// E = Entrez
#define O 0x4F
#define A 0x41
#define E 0x45
    
typedef enum
{
	/* Application's state machine's initial state. */
	APP_STATE_INIT=0,
	APP_STATE_SERVICE_TASKS,

	/* TODO: Define states used by the application state machine. */

} APP_STATES;

typedef enum
{
    WAIT=0,
    ASK,
    WAIT_ANSWER,
} APP_STEP;

typedef struct
{
    bool occupe;
    bool attendez;
    bool entrez;
} APP_ANSWER;


typedef struct
{
    /* The application's current state */
    APP_STATES state;

    /* TODO: Define any additional data used by the application. */

} APP_DATA;


//Variable du temps en seconde
unsigned short TEMPS = 0;

void APP_Initialize ( void );
void APP_Tasks( void );
void PORTS_INIT();


#endif /* _APP_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END


