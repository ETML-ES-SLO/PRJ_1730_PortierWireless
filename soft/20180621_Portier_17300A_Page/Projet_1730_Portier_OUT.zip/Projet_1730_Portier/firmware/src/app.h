#ifndef _APP_H
#define _APP_H



#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 


//DEFINI LES ADRESSE
#define ADRESSE1 0x0020B626
#define ADRESSE2 0x0021538D
#define MY_ADDRESS 0x0021500A
    
// F = bat Full
// L = Low bat
#define F 0x46
#define L 0x4C
    
// O = Occup�
// A = Attendez
// E = Entrez
#define O 0x4F
#define A 0x41
#define E 0x45
    
typedef enum
{
	/* Application's state machine's initial state. */
	APP_STATE_INIT=0,
    APP_WAIT,
	APP_STATE_SERVICE_TASKS,

	/* TODO: Define states used by the application state machine. */

} APP_STATES;

//Structure du graphe des �tats
typedef enum
{
    READ_BAT=0,
    REQUEST,
    WAIT,
    ANSWER, 
    END,
    ERROR,
} APP_STEP;



typedef struct
{
    /* The application's current state */
    APP_STATES state;

    /* TODO: Define any additional data used by the application. */

} APP_DATA;




//Variable du temps en seconde
unsigned short TEMPS = 0;



//Prototypes
void APP_Initialize ( void );

void APP_Tasks( void );

void PORTS_INIT();


#endif /* _APP_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END


