#include "GestBuzzer.h"
#include "peripheral/ports/plib_ports.h"



void singLa()
{
    //Joue un LA
    //11 * 100 us fait une demi periode de 440Hz (La)
    if(BUZ_TIME < (11))
    {
        //Mets la sortie buzzer � 0
        PLIB_PORTS_PinWrite(0,0x01,15, false);

        //Pour test de la frequence
        //PLIB_PORTS_PinWrite(PORTS_ID_0, 0, 4, true);
    }
    else
    {
        //Mets la sortie buzzer � 1
        PLIB_PORTS_PinWrite(0,0x01,15, true);
        //Reset quand l'autre demi periode est teminee
        if(BUZ_TIME > (22))
        {
            BUZ_TIME = 0;
        }

        //Pour test
        //PLIB_PORTS_PinWrite(PORTS_ID_0, 0, 4, false);
    }
}



void singDo()
{
    //Joue un DO
    //19 * 100 us fait une demi periode de 263Hz (Do)
    if(BUZ_TIME < 19)
    {
        //Mets la sortie buzzer � 1
        PLIB_PORTS_PinWrite(0,0x01,15, false);
        
        //Pour test de la frequence
        PLIB_PORTS_PinWrite(PORTS_ID_0, 0, 4, true);
    }
    else
    {
        //Mets la sortie buzzer � 1
        PLIB_PORTS_PinWrite(0,0x01,15, true);
        //Reset quand l'autre demi periode est teminee
        if(BUZ_TIME > 38)
        {
            BUZ_TIME = 0;
        }
        
        //Pour test
        PLIB_PORTS_PinWrite(PORTS_ID_0, 0, 4, false);
    }
}