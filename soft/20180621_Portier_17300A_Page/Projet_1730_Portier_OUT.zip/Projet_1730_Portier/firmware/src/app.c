#include "app.h"
#include "GestBuzzer.h"
#include "Mc32gest_RS232.h"
#include "DriverAdc.h"



static APP_DATA appData;
static APP_STEP progress;

ADCResults ADC_Data;


void APP_Initialize ( void )
{
    //Activation de l'auto alimentation
    PLIB_PORTS_PinWrite(0,0x01,0,true);
    
    //Ouverture du port ADC
    DRV_ADC_Open();

    
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;
    progress = READ_BAT;
    TEMPS = 0;
}



void APP_Tasks ( void )
{
    //Variable pour placer la tension de la pile
    //static uint16_t tensionPile = 0;
     
    //Initialise � 'F' pour Full bat
    static uint8_t dataPile = F;
    
    
    //Variable de reception data module IN
    static uint8_t answerForUser = 0;
    
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            //Initialisation des PORTS
            PORTS_INIT();

            //Start les Timers
            DRV_TMR0_Start();
            DRV_TMR1_Start();
            
            
            
            appData.state = APP_STATE_SERVICE_TASKS;
            break;
        }

        case APP_STATE_SERVICE_TASKS:
        {
            switch(progress)
            {
                //Lecture tension des piles
                case READ_BAT:
                    
                    //Lecture dans ADC_Data
                    ADC_Data = ReadAllADC();
                                        
                    //Si tension trop basse (1.6V min)
                    // 2.048V -> 1023
                    //1.6V -> 799
                    if(ADC_Data.Chan0 < 800)
                    {
                        //indique 'L' pour Low bat
                        dataPile = L;
                    }
                    //Passe � l'�tape suivante
                    progress = REQUEST;
                    break;
                
                //Envois de la requ�te (avec la tension des piles)
                case REQUEST:
                    
                    
                    //Envois au module 1 et 2
           
                    sendMessage(ADRESSE1, dataPile);
                            
                    sendMessage(ADRESSE2, dataPile);
                    
                    //Passe � l'�tape suivante
                    progress = WAIT;
                    break;
                    
                //Attends r�ponse
                case WAIT:

                    //Si Re�ois un message
                    if(GetMessage(&answerForUser))
                    {
                        //Passe � l'�tape suivante
                        progress = ANSWER;
                        //reset le temps
                        TEMPS = 0;
                        //Eteint la LED occupe
                        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, false);
                    }

                    //Si on sonne � nouveau
                    if(PLIB_PORTS_PinGet(PORTS_ID_0, 0x01, 1))
                    {
                        //Attend qu'on relache le poussoir
                        while(PLIB_PORTS_PinGet(PORTS_ID_0, 0x01, 1))
                        {
                            //R�initalise le temps
                            TEMPS = 0;
                        }
                        //Renvois une requ�te
                        progress = REQUEST;
                    }
                    
                    //Si attendu trop longtemps
                    if(TEMPS >= 30)
                    {
                        //Buzzer sonne 1s
                        singDo();
                        //Quand la seconde est finie
                        if(TEMPS >= 31)
                        {
                            //Passe � l'�tape de fin
                            progress = END;
                        }
                        
                    }
                    
                    break;
                
                //Indiquer la r�ponse
                case ANSWER:
                    //Selon la r�ponse lue
                    switch(answerForUser)
                    {
                        //Pour occupe
                        case O:
                            //Allume LED Occupe
                            PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, true);
                            break;
                        //Pour attendez
                        case A:
                            //Allume LED Attendez
                            PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, true);
                            break;
                        //Pour entrez
                        case E:
                            //Allume LED Entrez
                            PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, true);
                            break;
                        //En cas de valeur fausse
                        default:
                            //Entre dans une phase d'erreur
                            progress = ERROR;
                            break;
                    }
                    
                    //Sonne pendant 2 secondes
                    if(TEMPS > 2)
                    {
                        //Passe � l'�tape de fin
                        progress = END;
                    }
                    singLa();
                    break;                    
                    
                //Eteint le systeme
                case END:
                    
                    //Eteint l'auto alimentation
                    PLIB_PORTS_PinWrite(0,0x01,0,false);
                    break;
                    
                case ERROR:
                    
                    //Clignote tout pendant 5s
                    if(TEMPS == 1 || TEMPS == 3 || TEMPS == 5)
                    {
                        PLIB_PORTS_PinToggle(PORTS_ID_0, 0x01, 4);
                        PLIB_PORTS_PinToggle(PORTS_ID_0, 0x01, 5);
                        PLIB_PORTS_PinToggle(PORTS_ID_0, 0x01, 6);
                    }
                    //Eteint
                    else if(TEMPS == 6)
                    {
                        progress = END;
                    } 
                    break;
                default:
                    break;
            }  
            break;
        }


        default:
        {

            break;
        }
    }
}

void PORTS_INIT()
{
    //LEDs --> Allume "Occup�"
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 6, true);
    //Eteint "Attendez" & "Entrez"
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 5, false);
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, false);
    
    //BUZZER maintient inactif
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 15, false);
    
    //Module RF
    
    //Reset � 1
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 12, false);
    
        
    // To set reset(M) low :
//    _TRISB12=0;
    
      // To set reset(M) high :
//    _TRISB12=1;
    
    
    //Connect � 1
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 13, true);
    
    
    //Attends que LINK passe a 1
    //PORTB --> PIN 14 : LINK
    while(!PLIB_PORTS_PinGet(PORTS_ID_0, 0x01, 14))
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, true);
    }
    PLIB_PORTS_PinWrite(PORTS_ID_0, 0x01, 4, false);
    
    
    //SWITCHS
    //PORTB PIN 1 --> RING
}
