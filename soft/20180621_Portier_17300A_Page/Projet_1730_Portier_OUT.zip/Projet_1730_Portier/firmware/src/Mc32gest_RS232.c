#include <xc.h>
#include <sys/attribs.h>
#include "system_definitions.h"


#include <GenericTypeDefs.h>
#include "app.h"
#include "Mc32gest_RS232.h"



// avec int8_t besoin -86 au lieu de 0xAA
#define STX_code  170//0xAA//(-86)

// Structure d�crivant le message
typedef struct {
    uint8_t msb;
    uint8_t  byte2;
    uint8_t byte1;
    uint8_t lsb;
} StruAddr;


// Struct pour �mission de l'adresse
StruAddr addressTx;






/*******************************************************************************
 
                         *** Fonction sendMessage ***
 
 ******************************************************************************/

void sendMessage(unsigned int addr, uint8_t data)
{
    /*uint8_t ACKData = 0;
    bool error = false;*/
    
    //S�paration des bytes
    addressTx.msb = (addr & 0xFF000000) >> 24;
    addressTx.byte2 = (addr & 0x00FF0000) >> 16;
    addressTx.byte1 = (addr & 0x0000FF00) >> 8;
    addressTx.lsb = addr & 0x000000FF;  
    
    
    //Envoi de la trame UART
    while(PLIB_USART_TransmitterBufferIsFull(USART_ID_1));
    //Start
    PLIB_USART_TransmitterByteSend(USART_ID_1,STX_code);
    
    //Mode bidirectionnel = 0
    PLIB_USART_TransmitterByteSend(USART_ID_1,0x00);
    
    //Adresse
    PLIB_USART_TransmitterByteSend(USART_ID_1,addressTx.msb);
    PLIB_USART_TransmitterByteSend(USART_ID_1,addressTx.byte2);
    PLIB_USART_TransmitterByteSend(USART_ID_1,addressTx.byte1);
    PLIB_USART_TransmitterByteSend(USART_ID_1,addressTx.lsb);
    
    //Data
    PLIB_USART_TransmitterByteSend(USART_ID_1,data);

}




/*******************************************************************************
 
                          *** Fonction GetMessage ***
 
 ******************************************************************************/


bool GetMessage(uint8_t *dataRecieved)
{    
    static uint8_t situation = 1;
    uint8_t c = 0;
    unsigned int address = 0;
    bool messRecu = false;
    // Struct pour �mission de l'adresse
    static StruAddr addressRx;
    
    //Lecture d'un caractere
    while(PLIB_USART_ReceiverDataIsAvailable(USART_ID_1))
    { 
        //Lecture dans c
        c = PLIB_USART_ReceiverByteReceive(USART_ID_1);
        // Traitement selon �tat du message
        switch (situation) 
        {
            //Case de test du start
            case 1:
                if(c == STX_code) 
                {
                    situation++;
                    //messRecu = true;
                }
                break;
            //Prise du com
            case 2:
                situation++;
                break;
            //Prise MSB
            case 3:
                addressRx.msb = c;
                situation++;
                break;
            //Prise byte2
            case 4:
                addressRx.byte2 = c;
                situation++;
                break;
            //Prise byte1
            case 5:
                addressRx.byte1 = c;
                situation++;
                break;
            //Prise LSB
            case 6:
                addressRx.lsb = c;
                situation++;
                break;
            //Prise data
            case 7:
                //Masque des bits qui nous int�ressent -> diminue l'erreur
                *dataRecieved = c;
                
                //Recomposition de l'adresse
                address = (addressRx.msb << 24) + (addressRx.byte2 << 16)
                        + (addressRx.byte1 << 8) + addressRx.lsb;
                
                //Si l'adresse correspond
                if(address == MY_ADDRESS)
                {
                    //Indique un message re�u
                    messRecu = true;                   
                }
                situation = 1;
                    
                break;

            default:
                //Retourne en position de d�part
                situation = 1;
                //Indique message non re�u
                messRecu = false;
                break;
        } // end switch
    }
        
    return messRecu;
}