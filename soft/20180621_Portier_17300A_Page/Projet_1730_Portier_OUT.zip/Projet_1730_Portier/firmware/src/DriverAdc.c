/*--------------------------------------------------------*/
//  Mc32DriverAdc.c
/*--------------------------------------------------------*/
//	Description :	Fonctions pour gestion ADC 10 bits
//                      en mode scan
//	Auteur 		: 	C. HUBER
//					
//	Version		:	V1.0
//	Compilateur	:	XC32 V1.33 & Harmony 1.00
//
//      BSP             :  pic32mx_skes
//
// Revu / modifi�:
//      cr�ation 18.09.2014 CHR
/*--------------------------------------------------------*/

#include "system_config.h"
#include "DriverAdc.h"
#include "peripheral/adc/plib_adc.h"
#include "framework/driver/adc/drv_adc_static.h"



// Create the list of  channels to scan
// Bit a 1  SCAN Bit0 = AN0
#define configscan  0x0002       // AN1 

/*--------------------------------------------------------*/
// Fonction ReadAllADC
/*--------------------------------------------------------*/

ADCResults ReadAllADC()
{
    ADCResults result;
    
    // On start la conversion
    DRV_ADC_Start();
    
    // On attend les �chantillons
    while (!DRV_ADC_SamplesAvailable());
    
    // On prend la valeur sortie du convertisseur
    result.Chan0 = (uint16_t)DRV_ADC_SamplesRead(0);
    
    // On stop la conversion pour �viter de convertir tout le temps
    DRV_ADC_Stop();
    
    //DRV_ADC_Close();
   
    return result;
}
