/* 
 * File:   GestBuzzer.h
 * Author: pageis
 *
 * Created on 6. mars 2018, 16:13
 */

#ifndef GESTBUZZER_H
#define	GESTBUZZER_H

#include <stdlib.h>
#include <stdbool.h>

#ifdef	__cplusplus
extern "C" {
#endif
    
//Prototypes
void singLa();
void singDo();

//Variable de temps pour g�rer les notes
unsigned int BUZ_TIME;


#ifdef	__cplusplus
}
#endif

#endif	/* GESTBUZZER_H */

